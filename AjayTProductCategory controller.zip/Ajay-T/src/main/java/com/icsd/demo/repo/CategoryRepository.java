package com.icsd.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.icsd.demo.model.Category;
import com.icsd.demo.model.User;

public interface CategoryRepository extends JpaRepository<Category,Long>
{

	
}
