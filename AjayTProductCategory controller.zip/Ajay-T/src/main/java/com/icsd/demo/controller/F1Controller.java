package com.icsd.demo.controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class F1Controller {
	@RequestMapping(value="/ajay",method=RequestMethod.GET)
	public String fun1()
	{
		String str="hello icssddsd";
		
		return str;
	}
}
