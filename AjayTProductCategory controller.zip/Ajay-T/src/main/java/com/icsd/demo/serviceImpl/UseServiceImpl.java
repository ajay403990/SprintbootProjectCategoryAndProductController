package com.icsd.demo.serviceImpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icsd.demo.model.Category;
import com.icsd.demo.model.User;
import com.icsd.demo.repo.CategoryRepository;
import com.icsd.demo.repo.UserRepository;
import com.icsd.demo.service.UserService;
@Service
public class UseServiceImpl implements UserService {

	@Autowired
    UserRepository er;
	
//
	

	@Override
	public List<User> getUserList() {		
		
       return er.findAll();
	}
//	@Override
//	public EmpTblModel getEmployeeById(int empid) {
//		// TODO Auto-generated method stub
//		return er.findById(empid).get();
//		
//		
//	}
//
//	@Override
//	public EmpTblModel addEmployee(EmpTblModel emp) {
//		// TODO Auto-generated method stub
//		EmpTblModel e=er.save(emp);
//		return e;
//	}
//
//	@Override
//	public void deleteEmp(int empid) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void updateEmp(EmpTblModel emp) {
//		// TODO Auto-generated method stub
//		
//	}
	
	@Override
	public void addUser(User objUser) {
		// TODO Auto-generated method stub
	   er.save(objUser);
	}

	
//	@Override
//	public boolean checkLogin(String userName, String password) {
//		// TODO Auto-generated method stub
//
//	User u=er.findByEmailAndPwd(userName, password);
//	
//
//return false;
//	}

	@Override
	public boolean checkLogin(String email, String password) {
	    // TODO Auto-generated method stub
	    
	    List<User> u = er.findByEmailAndPwd(email, password);
	    
	    if (u!=null) {
	        System.out.println("email and password are correct");
	        return true;
	    } else {
	        System.out.println("Username and password not found");
	        return false;
	    }
	}


//localhost:8006/user/23
@Override
public User getUserById(Long userId) {
    // No need to typecast Long to int
    return er.findById(userId).get();
}

@Override
public void deleteuser(long userid) {
	// TODO Auto-generated method stub
er.deleteById(userid);	
}

@Override
public void updateEmp(User user) {
	// TODO Auto-generated method stub
	er.save(user);
}

@Override
public User getUser() {
	// TODO Auto-generated method stub
	return null;
}


}
