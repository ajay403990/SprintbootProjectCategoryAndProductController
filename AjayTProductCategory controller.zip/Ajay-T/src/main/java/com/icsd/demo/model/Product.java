package com.icsd.demo.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import org.springframework.lang.NonNull;


@Entity(name = "dbo.Product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generat")
    @SequenceGenerator(name = "generat", sequenceName = "ID_SEQUEN", allocationSize = 1)
    @Column(name = "Product_Id")
    private long productId;
    @ManyToOne
    @JoinColumn(name = "category_id")
 
    private Category category;

    @NonNull
    @Column(name = "Product_Name")
    private String productName;

    @NonNull
    @Column(name = "Product_Desc")
    private String productDesc;

    @NonNull
    @Column(name = "Product_imgbyurl")
    private String productImgByUrl;

    @NonNull
    @Column(name = "Qty")
    private int qty;

    @NonNull
    @Column(name = "Price")
    private Float price;


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", categoryId=" + category + ", productName=" + productName
				+ ", productDesc=" + productDesc + ", productImgByUrl=" + productImgByUrl + ", qty=" + qty + ", price="
				+ price + "]";
	}

	public Product(Category category, String productName, String productDesc, String productImgByUrl,
			int qty, Float price) {
		super();
		this.category = category;
		this.productName = productName;
		this.productDesc = productDesc;
		this.productImgByUrl = productImgByUrl;
		this.qty = qty;
		this.price = price;
	}

	public Category getCategoryId() {
		return category;
	}

	public void setCategoryId(Category categoryId) {
		this.category = categoryId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}



	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductImgByUrl() {
		return productImgByUrl;
	}

	public void setProductImgByUrl(String productImgByUrl) {
		this.productImgByUrl = productImgByUrl;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Product() {
		super();
	}

   
}
