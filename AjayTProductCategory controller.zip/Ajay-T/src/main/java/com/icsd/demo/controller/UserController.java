package com.icsd.demo.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.icsd.demo.model.User;
import com.icsd.demo.service.UserService;

@RestController
@CrossOrigin(origins="*")
public class UserController 
{

	@Autowired
	UserService us;
	
	@GetMapping("/saveUserTbl")
	public void addUser()
	{
		//json - ename in json is smae as ename variabvle in class emp.
		System.out.println("hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
//		public User( @NotNull String name, @NotNull String password, String mobile, String email,
//				int userType, String createdBy, Date createdDateTime, int active, Date lastupdate)
		com.icsd.demo.model.User objUser=new User( "titu", "1234","987654123", "icsd@icsd.com", 1, "createdByyy", new Date(), 0, new Date());
		System.out.println(objUser);
		
		 us.addUser(objUser);
	}
	
	
	@GetMapping("/userList")
	public   List<User> getUserList()
	{
		System.out.println("fun called 10 ");
		return us.getUserList();
	}
//	@GetMapping("/user/{user_id}")
//	public User getuserById(@PathVariable("user_id") Long user_id) {
//	    System.out.println("inside get with id");
//	    return us.getUserById(user_id);
//	}
//	
	@GetMapping("/user/{userid}")
	public User getEmployeeById(@PathVariable("userid") long userid)//employess/1
	//path param- employees/1-- this is pura url.
	{
		System.out.println("insde get with id");
		return us.getUserById(userid);
	}
//
//	{
//	    "user_id": 4,
//	    "name": "Bitu",
//	    "pwd": "123",
//	    "mobile": "300",
//	    "email": "aj23@gmail.com",
//	    "userType": 1,
//	    "createdBy": "createdby",
//	    "createdDateTime": "2024-03-03T05:28:42.205+00:00",
//	    "active": 1,
//	    "lastupdate": "800"
//	}

	@PostMapping("/user")
	public void addUser(@RequestBody User user)
	{
		//json - ename in json is smae as ename variabvle in class emp.
		System.out.println("hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
		System.out.println(user.getUserId());
		System.out.println("Date received is : "+ user);
		 us.addUser(user);
	}
	
	@PostMapping("/loginUser")
	public boolean doLogin(@RequestBody User  objUser)
	{
		System.out.println("login User ");
		System.out.println(objUser.getEmail()+" pwd = "+ objUser.getPwd());
		System.out.println("inside login User "+ objUser);
		boolean res=us.checkLogin(objUser.getEmail(), objUser.getPwd());
		return res;
	}


	
//	
//	@PostMapping("/loginUser")
//	public boolean doLogin(@RequestBody User  objUser)
//	{
//		System.out.println("login User ");
//		System.out.println(objUser.getEmail()+" pwd = "+ objUser.getPwd());
//		System.out.println("inside login User "+ objUser);
//		boolean res=us.checkLogin(objUser.getEmail(), objUser.getPwd());
//		return res;
//	}
//	//localhost:8006/user/25
	@DeleteMapping("/user/{userid}")
	public void deleteEmployee(@PathVariable long userid)
	{
		System.out.println("inside delete");
		us.deleteuser(userid);
		
	}
//	
	@PutMapping("/user")
	public void updateEmployee(@RequestBody User user)
	{
		System.out.println(user.getUserId());
		System.out.println(user.getName());
		System.out.println(user.getPwd());
		System.out.println("insidde put");
		us.updateEmp(user);
	}

	
	
	
	
	
	
//	
	
//
//	@RequestMapping( value="/login",method=RequestMethod.POST)
//	public ResponseEntity doLogin(@RequestParam(value="name",required=true) String Username,@RequestParam(value="password",required=true) String password,@RequestParam(value="kioskId",required=true) String kisokId,HttpSession httpSession,HttpServletRequest request)
//	{
//		User user;
//		String status=null;
//		Map response= new HashMap();
//		try {	
//			user=loginService.checkLogin(Username,password,kisokId);
//			if(user!=null)
//				{
//				response.put("statusCode",HttpStatus.OK);
//				response.put("Status","Sucess");
//				response.put("user",user);
//				httpSession.setAttribute("requestedUser", user.getUserId());
//				httpSession.setAttribute("app_key", request.getHeader("app_key"));
//				}
//			else
//			{
//				status="failure";
//				response.put("Status",status);
//				response.put("statusCode","NOK");
//			}
//		}catch (Exception e) {
//			// TODO: handle exception
//			new ResponseEntity(HttpStatus.BAD_REQUEST);
//		}
//		return new ResponseEntity(response,HttpStatus.OK);
//	}

}