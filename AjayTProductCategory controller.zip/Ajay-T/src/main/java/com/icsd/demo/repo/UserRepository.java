package com.icsd.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.icsd.demo.model.Category;
import com.icsd.demo.model.User;




public interface UserRepository extends JpaRepository<User,Long>
{
//https://docs.spring.io/spring-data/jpa/docs/current-SNAPSHOT/reference/html/#reference
	public User findByNameAndPwd(String userName, String password);
	public List<User> findByEmailAndPwd(String email, String password);
	
	
 
	
}
