package com.icsd.demo.controller;

import com.icsd.demo.model.User;

public interface loginService {
     User checkLogin(String userName, String password, String kioskId);
}
