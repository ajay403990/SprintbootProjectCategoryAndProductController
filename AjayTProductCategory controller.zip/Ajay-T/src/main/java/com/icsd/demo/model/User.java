package com.icsd.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.lang.NonNull;

@Entity(name="dbo.User")
public class User 
{
	//run this command in oracle 
//	create sequence ID_SEQUENCE;
	@Id
	@NonNull
	@Column(name="User_Id")
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@SequenceGenerator(name = "generator", sequenceName = "ID_SEQUENCE", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generator")
	private long userId;
	
	@Column(name="Name")
	@NonNull
	private String name;

	@Column(name="pwd")
	@NonNull
	private String pwd;
	
	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	@Column(name="Mobile")
	private String mobile;
	
	@Column(name="email")
	private String email;
	
	@Column(name="Type")
	private int userType;
	
	@Column(name="Created_by")
	private String createdBy;
	
	@Column(name="Created_DateTime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDateTime;
	
	@Column(name="Active")
	private int active;
	
	@Column(name="Last_Update")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastupdate;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getUserType() {
		return userType;
	}

	public void setUserType(int userType) {
		this.userType = userType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public User() {
		super();
	}

	public User( @NonNull String name, @NonNull String pwd, String mobile, String email,
			int userType, String createdBy, Date createdDateTime, int active, Date lastupdate) {
		super();
		
		this.name = name;
		this.pwd = pwd;
		this.mobile = mobile;
		this.email = email;
		this.userType = userType;
		this.createdBy = createdBy;
		this.createdDateTime = createdDateTime;
		this.active = active;
		this.lastupdate = lastupdate;
	}

	public Date getLastupdate() {
		return lastupdate;
	}

	public void setLastupdate(Date lastupdate) {
		this.lastupdate = lastupdate;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", pwd=" + pwd + ", mobile=" + mobile
				+ ", email=" + email + ", userType=" + userType + ", createdBy=" + createdBy + ", createdDateTime="
				+ createdDateTime + ", active=" + active + ", lastupdate=" + lastupdate + "]";
	}
	
}