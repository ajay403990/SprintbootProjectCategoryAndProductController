package com.icsd.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.icsd.demo.model.Category;
import com.icsd.demo.service.CategoryService;

@RestController
@CrossOrigin(origins="*")
public class CategoryController 
{
	@Autowired
	CategoryService cs;
	
//	@RequestMapping(value="getCatById",method=RequestMethod.GET)
//	public String getCatById()
//	{
//		return "hello icsd";
//	}
	//	//{"catName":"laptop","catDesc":"desc","catImg":"l1.jpg","createdDate":"","modifiedDate":""}
	@RequestMapping(value="addCategory",method=RequestMethod.POST)
	public Category addCategory(@RequestBody Category c)	
	{
		
		System.out.println("data received from angular is "+ c);
		System.out.println("inside cat cer - data saved ");
		return cs.addCategory(c);
				
		
	}
	public boolean deleteCategoryById()
	{
		
		return false;
		
	}
	@RequestMapping(value="getAllCat",method=RequestMethod.GET)
	public List<Category > getAllCat()
	{
		System.out.println("cat cer - getAllCat() called ");
		return cs.getAllCat();
	}
	//localhost:8901/getEmpByEmpno?empno=803
	@RequestMapping(value="getCatByCatid",method=RequestMethod.GET)
	public List<Category > getAllCatByCatId(@RequestParam(value="catid") int catId)
	{
		System.out.println("cat cer - getAllCatByCatId() called ");
		return cs.getAllCat();
	}
	
//	//localhost:8901/getEmpByEmpno?empno=803
//	@RequestMapping(value="/getEmpByEmpno",method=RequestMethod.GET)
//	public Map<String,Object> getEmpByEmpno(@RequestParam(value="empno")int empno)
//	{
//		final HashMap<String, Object> map = new HashMap<>();
//
//		map.put("emp", empService.getEmployeeById(empno));
//
//		System.out.println("get all emp by empno controller called");
//		return map;
//		
//	}
	

}