package com.icsd.demo.service;

import java.util.List;
import com.icsd.demo.model.Product;
public interface ProductService {

	public void addProduct(Product objProject);
	public Product getAllProductsByCategoryId(long categoryid);
	public List<Product> getProductTable(long categoryId);
	public Product addProduct1(Product p);
	public String addProductByCategoryWise(long categoryId, long productId);
	public void addProd(Product p);
	public Product addProduct2(Product p ,long categoryId);

}
