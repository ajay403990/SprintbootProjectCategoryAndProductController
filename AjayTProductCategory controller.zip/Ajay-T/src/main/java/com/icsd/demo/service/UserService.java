package com.icsd.demo.service;

import java.util.List;

import org.springframework.core.io.Resource;

import com.icsd.demo.model.Category;
import com.icsd.demo.model.User;

public interface UserService {

	public void addUser(User objUser);
	public boolean checkLogin(String userName,String password);
	public User getUser();
	
	public User getUserById(Long userid);
	public void deleteuser(long userid);
	public void updateEmp(User user);
	public List<User> getUserList();

}

