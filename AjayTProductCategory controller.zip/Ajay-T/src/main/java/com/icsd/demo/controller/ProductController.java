package com.icsd.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.icsd.demo.model.Category;
import com.icsd.demo.model.Product;

import com.icsd.demo.service.ProductService;

@RestController
@CrossOrigin(origins="*")
public class ProductController {

	@Autowired
	ProductService cs;
	
//	{
//	    "categoryId": 1,
//	    "productId": 123,
//	    "product": {
//	        "productName": "DESC SUPER",
//	        "productDesc": "Dell",
//	        "productImgByUrl": "l2.jpg",
//	        "qty": 100,
//	        "price": 85000,
//	        "category": {
//	            "categoryId": 1,
//	            "categoryName": "CategoryName"
//	        }
//	    }
//	}
//
	@GetMapping("/saveProductTbl")
	public void addProduct()
	{
		//json - ename in json is smae as ename variabvle in class emp.
		System.out.println("hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
//		public User( @NotNull String name, @NotNull String password, String mobile, String email,
//				int userType, String createdBy, Date createdDateTime, int active, Date lastupdate)
		Category category=new Category();
		category.setCategoryId(30);
		com.icsd.demo.model.Product objProject=new Product(category,"descSuper","11.jpg"," saMSUNG",100, (float) 95000.0);
		System.out.println(objProject);
		
		 cs.addProduct(objProject);
	}

	
	@RequestMapping(value="addProduct",method=RequestMethod.POST)
	public Product addProduct1(@RequestBody Product p)	
	{
		System.out.println("data received from angular is "+ p);
		System.out.println("inside cat cer - data saved ");
		return cs.addProduct1(p);	
	}

	
////working pending in this  method	
//	@RequestMapping(value="addProduct",method=RequestMethod.POST)
//	public Product addProduct2(@RequestBody Product p,@RequestBody Long categoryid)	
//	{
//		System.out.println("data received from angular is "+ p);
//		System.out.println("inside cat cer - data saved ");
//		return cs.addProduct2(p);	
//	}

	
	
	
	
	
	
	
	
//  get product by productid=?

	//localhost:8005/getAllProductsByCatId?categoryid=28 
	@RequestMapping(value="getAllProductsByCatId",method=RequestMethod.GET)
	public Product getAllProductsBycatId(@RequestParam(value="categoryid") long categoryid)
	{
		
		System.out.println("prod cer - getAllProductsByCatId() called and catid is "+ categoryid);
		return cs.getAllProductsByCategoryId(categoryid);
	}
	
//
	
//	get product by catid=?

//	localhost:8005/28
	 @GetMapping("/{categoryId}")
	    public List<Product> getProductsByCategoryId(@PathVariable long categoryId) {
	        System.out.println(" categoryid" + categoryId);
	        return cs.getProductTable(categoryId);
	    }
	
	// localhost:8005/addproductbyCategoryWise?categoryId=1&productId=1
	  @PutMapping("/addproductbyCategoryWise")
	    public String addProductByCategoryWise(@RequestParam long categoryId, @RequestParam long productId) {
	        return cs.addProductByCategoryWise(categoryId, productId);
	    }
	//working pending in this controller   
//	  @RequestMapping(value="addProduct",method=RequestMethod.POST)
//		public void addProduct(@RequestBody Product p)
//		{
//			System.out.println("add Product Called ");
//			System.out.println(p);
//	//prod saved ProdModel [prodId=101, cat=CatModel [catId=61, catName=null, catDesc=null, catImg=null, createdDate=null, modifiedDate=null], prodName=woodland, prodDesc=desc, prodImg=c2.jpg, prodPrice=7500.0, qty=100, createdDate=Mon Jan 01 05:30:00 IST 2001, modifiedDate=Thu Oct 10 05:30:00 IST 1000]
//			cs.addProd(p);
//			System.out.println("inside prod er - prod saved is "+ p);
//		}

	   
}
