package com.icsd.demo.service;

import java.util.List;

import com.icsd.demo.model.Category;

public interface CategoryService {

	Category addCategory(Category c);

	List<Category> getAllCat();
	
	
}
