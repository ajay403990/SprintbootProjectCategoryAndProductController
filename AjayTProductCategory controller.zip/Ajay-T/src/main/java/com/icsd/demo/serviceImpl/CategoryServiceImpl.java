package com.icsd.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icsd.demo.model.Category;
import com.icsd.demo.repo.CategoryRepository;
import com.icsd.demo.service.CategoryService;
@Service
public class CategoryServiceImpl implements CategoryService{

	@Autowired
	CategoryRepository cr;

	@Override
	public Category addCategory(Category c) {
		// TODO Auto-generated method stub
		return cr.save(c);
	}

	@Override
	public List<Category> getAllCat() {
		// TODO Auto-generated method stub
		return cr.findAll();
	}
	
	
	
	
	
//	@Override
//	public void addCategory(Category objCategory) {
//		// TODO Auto-generated method stub
//		err.save(objCategory);
//	}
//	@Override
//	public List<Category> getCategoryList() {
//		// TODO Auto-generated method stub
//		return err.findAll();
//	}
//	@Override
//	public Category getCategoryById(long categoryid) {
//		// TODO Auto-generated method stub
//		return err.findById(categoryid).get();
//	}
//	@Override
//	public void addCAtegory(Category category) {
//	
//		err.save(category);
//	}
//	@Override
//	public void addCategory1(Category Category) {
//		// TODO Auto-generated method stub
//		err.save(Category);
//	}
//	@Override
//	public void addCategory2(Category category) {
//		// TODO Auto-generated method stub
//		err.save(category);
//	}
	
}
