package com.icsd.demo.serviceImpl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.icsd.demo.model.Category;
import com.icsd.demo.model.Product;
import com.icsd.demo.repo.CategoryRepository;
import com.icsd.demo.repo.ProductRepository;
import com.icsd.demo.service.ProductService;
@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductRepository err;
	@Autowired
	CategoryRepository cs;
	
	@Override
	public void addProduct(Product objProduct) {
		// TODO Auto-generated method stub
		err.save(objProduct);
	}

	@Override
	public Product getAllProductsByCategoryId(long categoryid) {
		// TODO Auto-generated method stub
		return err.findById(categoryid).get();
	}

	  @Override
	    public List<Product> getProductTable(long categoryId) {
	        return err.findByCategoryCategoryId(categoryId);
	    }

	@Override
	public Product addProduct1(Product p) {
	
		
		return err.save(p) ;
	}
	
//	  Category category = cs.findById(categoryId).get();
//	  product.setCategoryId(category);      
//	Product p, Long categoryId

	  @Override
	    public String addProductByCategoryWise(long categoryId, long productId) {
	        Category category = cs.findById(categoryId).get();
	        Product product = err.findById(productId).get();

	        product.setCategoryId(category);
	        err.save(product);
	        return "Product updated successfully in categorywise.";
	    }

	@Override
	public void addProd(Product p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Product addProduct2(Product p, long categoryId) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public Product addProduct2(Product p,Long categoryId) {
//		// TODO Auto-generated method stub
//		  Category category = cs.findById(categoryId).get();
//		   
//		  Product.setCategoryId(category);      
//		
//
//		return err.save(p);
//	}

//	  @Override
//	  public void addProduct1(Product p) {
//	      // Save the product using the repository
//	     return err.save(p);
//	  }


}
