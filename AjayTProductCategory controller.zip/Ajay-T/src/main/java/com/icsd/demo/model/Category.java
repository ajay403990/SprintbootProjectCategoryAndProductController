package com.icsd.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.springframework.lang.NonNull;

@Entity(name = "dbo.Category")
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generato")
    @SequenceGenerator(name = "generato", sequenceName = "ID_SEQUENC", allocationSize = 1)
    @NonNull
    @Column(name = "Category_Id")
    private long categoryId;

    @NonNull
    @Column(name = "Category_Name")
    private String categoryName;

    @NonNull
    @Column(name = "Category_Desc")
    private String categoryDesc;

    @NonNull
    @Column(name = "Category_imgbyurl")
    private String categoryImgByUrl;
    
    @OneToMany(targetEntity = Product.class, mappedBy = "category")
    private List<Product> products;

    public Category() {
        super();
    }

    public Category(@NonNull String categoryName,@NonNull String categoryDesc,@NonNull String categoryImgByUrl) {
        super();
        this.categoryName = categoryName;
        this.categoryDesc = categoryDesc;
        this.categoryImgByUrl = categoryImgByUrl;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryDesc() {
        return categoryDesc;
    }

    public void setCategoryDesc(String categoryDesc) {
        this.categoryDesc = categoryDesc;
    }

    public String getCategoryImgByUrl() {
        return categoryImgByUrl;
    }

    public void setCategoryImgByUrl(String categoryImgByUrl) {
        this.categoryImgByUrl = categoryImgByUrl;
    }

    @Override
    public String toString() {
        return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + ", categoryDesc=" + categoryDesc
                + ", categoryImgByUrl=" + categoryImgByUrl + "]";
    }
}
